<?php /* Wrapper Name: Header */ ?>

<?php get_template_part("static/static-logo"); ?>

<div class="top_search hidden-phone" data-motopress-type="static" data-motopress-static-file="static/static-search.php">
	<?php get_template_part("static/static-search"); ?>
</div>

<?php get_template_part("static/static-nav"); ?>

<div class="clear"></div>